
const data = {
  
  heroes: {
    'hero-1': {id: 'hero-1', name: 'Beyond Better Foods (Enlightened)'},
    'hero-2': {id: 'hero-2', name: 'Dole packaged'},
    'hero-3': {id: 'hero-3', name: 'Nestle - Hot Pockets'},
    'hero-4': {id: 'hero-4', name: 'Lakeview Farms '},
    'hero-5': {id: 'hero-5', name: ' Barilla'},
    'hero-6': {id: 'hero-6', name: 'Idahoan'},
    'hero-7': {id: 'hero-7', name: 'Bob Evans'}
 
  },

  columns: {
    'column-1': { id: 'column-1', title: "CATALINA CLIENTS", heroId: ['hero-1','hero-2','hero-3','hero-4'] },
    'column-2': {id: 'column-2', title: 'NOTIFIED CLIENTS',  heroId: ['hero-5','hero-6']},
    'column-3': { id: 'column-3', title:'NON-NOTIFIED CLIENTS', heroId: ['hero-7']}
  },

  columnsort: ['column-1', 'column-2', 'column-3']

}
export default data;